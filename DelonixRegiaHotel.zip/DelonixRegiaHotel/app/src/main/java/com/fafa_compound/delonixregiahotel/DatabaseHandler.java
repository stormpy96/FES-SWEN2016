package com.fafa_compound.delonixregiahotel;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fafa_compound on 8/6/2016.
 */
public class DatabaseHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "myHotel";

    //diff tables
    private static final String TABLE_STAFF = "staffs";
    private static final String TABLE_ROOM = "rooms";

    //common column names
    //    private static final String KEY_ID = "id";
    private static final String KEY_ID = "id";

    //    Staff columns
    private static final String KEY_STAFFFIRSTNAME = "stafffirstname";
    private static final String KEY_STAFFFLASTNAME = "staffflastname";
    private static final String KEY_CONTACTDETAILS = "contactdetails";
    private static final String KEY_STAFFEMAIL = "staffemail";
    private static final String KEY_STAFFADDRESS = "staffaddress";
    private static final String KEY_BANKACCOUNT = "bankaccount";

    // Room columns
    private static final String KEY_ROOMID = "roomid";
    private static final String KEY_CHECKINDATE = "checkindate";
    private static final String KEY_CHECKOUTDATE = "checkoutdate";
    private static final String KEY_CHECKINTIME = "checkintime";
    private static final String KEY_CHECKOUTTIME = "checkouttime";
    private static final String KEY_FIRSTNAME = "firstname";
    private static final String KEY_LASTNAME = "lastname";
    private static final String KEY_NOOFADULTS = "noofadults";
    private static final String KEY_NOOFCHILDREN = "noofchildren";
    private static final String KEY_CONTACTNUMBER = "contactnumber";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_ADDRESS = "address";
    private static final String KEY_CREDITCARDTYPE = "creditcardtype";
    private static final String KEY_CASH = "cash";
    private static final String KEY_LATECHECKOUTREQUEST = "latecheckoutrequest";
    private static final String KEY_ROOMTYPE = "roomtype";

    //table create statements

    // travel table create statement

    private static final String CREATE_TABLE_STAFF = "CREATE TABLE " + TABLE_STAFF + "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + KEY_STAFFFIRSTNAME + " TEXT, " + KEY_STAFFFLASTNAME + " TEXT, " + KEY_CONTACTDETAILS + " TEXT, " + KEY_STAFFEMAIL + " TEXT, " + KEY_STAFFADDRESS + " TEXT, " + KEY_BANKACCOUNT + " TEXT)";

    private static final String CREATE_TABLE_ROOM = "CREATE TABLE " + TABLE_ROOM + "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + KEY_ROOMID + " TEXT, " + KEY_CHECKINDATE + " TEXT, " + KEY_CHECKOUTDATE + " TEXT, " + KEY_CHECKINTIME + " TEXT, " + KEY_CHECKOUTTIME + " TEXT, " + KEY_FIRSTNAME + " TEXT, " +  KEY_LASTNAME + " TEXT, " + KEY_NOOFADULTS + " TEXT, " + KEY_NOOFCHILDREN +
            " TEXT, " + KEY_CONTACTNUMBER + " TEXT, " + KEY_EMAIL + " TEXT, " + KEY_ADDRESS + " TEXT, " + KEY_CREDITCARDTYPE + " TEXT, " + KEY_CASH + " TEXT, " + KEY_LATECHECKOUTREQUEST + " TEXT, " + KEY_ROOMTYPE + " TEXT)";

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_TABLE_STAFF);
        db.execSQL(CREATE_TABLE_ROOM);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STAFF);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ROOM);
        onCreate(db);
    }

//---------------------C R U D Room-----------------------------
    public long createRoom (Room room) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ROOMID, room.getRoomid());
        values.put(KEY_CHECKINDATE, room.getCheckindate());
        values.put(KEY_CHECKOUTDATE, room.getCheckoutdate());
        values.put(KEY_CHECKINTIME, room.getCheckintime());
        values.put(KEY_CHECKOUTTIME, room.getCheckouttime());
        values.put(KEY_FIRSTNAME, room.getFirstname());
        values.put(KEY_LASTNAME, room.getLastname());
        values.put(KEY_NOOFADULTS, room.getNoofadults());
        values.put(KEY_NOOFCHILDREN, room.getNoofchildren());
        values.put(KEY_CONTACTNUMBER, room.getContactnumber());
        values.put(KEY_EMAIL, room.getEmail());
        values.put(KEY_ADDRESS, room.getAddress());
        values.put(KEY_CREDITCARDTYPE, room.getCreditcardtype());
        values.put(KEY_CASH, room.getCash());
        values.put(KEY_LATECHECKOUTREQUEST, room.getLatecheckoutrequest());
        values.put(KEY_ROOMTYPE, room.getRoomtype());

        long result = db.insert(TABLE_ROOM, null, values);
        db.close();
        return result;
    }

    public Room getRoom(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_ROOM,
                new String[] {KEY_ID, KEY_ROOMID, KEY_CHECKINDATE, KEY_CHECKOUTDATE, KEY_CHECKINTIME, KEY_CHECKOUTTIME, KEY_FIRSTNAME, KEY_LASTNAME, KEY_NOOFADULTS, KEY_NOOFCHILDREN, KEY_CONTACTNUMBER, KEY_EMAIL, KEY_ADDRESS, KEY_CREDITCARDTYPE, KEY_CASH, KEY_LATECHECKOUTREQUEST, KEY_ROOMTYPE}, KEY_ID + "=?",
                new String[] {String.valueOf(id)},null, null, null, null);
        if (cursor != null) {	// the record is available
            cursor.moveToFirst();  // should only get ONE contact
            Room room = new Room(Integer.parseInt(cursor.getString(0)),
                    cursor.getString(1), cursor.getString(2),
                    cursor.getString(3), cursor.getString(4),
                    cursor.getString(5), cursor.getString(6),
                    cursor.getString(7), cursor.getString(8),
                    cursor.getString(9), cursor.getString(10),
                    cursor.getString(11), cursor.getString(12),
                    cursor.getString(13), cursor.getString(14),
                    cursor.getString(15), cursor.getString(16));
            cursor.close();
            db.close();
            return room;
        }
        else {  // no record for the id provided
            cursor.close();
            db.close();
            return null;
        }
    }

    public int deleteRoom(Room room) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsAffected = db.delete(TABLE_ROOM, KEY_ID + "=?",
                new String[]{String.valueOf(room.getId())});
        db.close();
        return rowsAffected;
    }

    public int getRoomCount() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ROOM, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();
        return count;
    }

    public int updateRoom(Room room) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ROOMID, room.getRoomid());
        values.put(KEY_CHECKINDATE, room.getCheckindate());
        values.put(KEY_CHECKOUTDATE, room.getCheckoutdate());
        values.put(KEY_CHECKINTIME, room.getCheckintime());
        values.put(KEY_CHECKOUTTIME, room.getCheckouttime());
        values.put(KEY_FIRSTNAME, room.getFirstname());
        values.put(KEY_LASTNAME, room.getLastname());
        values.put(KEY_NOOFADULTS, room.getNoofadults());
        values.put(KEY_NOOFCHILDREN, room.getNoofchildren());
        values.put(KEY_CONTACTNUMBER, room.getContactnumber());
        values.put(KEY_EMAIL, room.getEmail());
        values.put(KEY_ADDRESS, room.getAddress());
        values.put(KEY_CREDITCARDTYPE, room.getCreditcardtype());
        values.put(KEY_CASH, room.getCash());
        values.put(KEY_LATECHECKOUTREQUEST, room.getLatecheckoutrequest());
        values.put(KEY_ROOMTYPE, room.getRoomtype());

        int rowsAffected = db.update(TABLE_ROOM, values, KEY_ID + "=?",
                new String[]{String.valueOf(room.getId())});
        db.close();
        return rowsAffected;
    }

    public List<Room> getAllRoom() {
        List<Room> rooms = new ArrayList<Room>();
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ROOM, null);
        if (cursor.moveToFirst()){
            do {
                rooms.add(new Room(Integer.parseInt(cursor.getString(0)),
                        cursor.getString(1), cursor.getString(2),
                        cursor.getString(3), cursor.getString(4),
                        cursor.getString(5), cursor.getString(6),
                        cursor.getString(7), cursor.getString(8),
                        cursor.getString(9), cursor.getString(10),
                        cursor.getString(11), cursor.getString(12),
                        cursor.getString(13), cursor.getString(14),
                        cursor.getString(15), cursor.getString(16)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return rooms;
    }


//---------------------C R U D STAFF-----------------------------
    public long createStaff (Staff staff) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_STAFFFIRSTNAME, staff.getStafffirstname());
        values.put(KEY_STAFFFLASTNAME, staff.getStafflastname());
        values.put(KEY_CONTACTDETAILS, staff.getContactdetails());
        values.put(KEY_STAFFEMAIL, staff.getStaffemail());
        values.put(KEY_STAFFADDRESS, staff.getStaffaddress());
        values.put(KEY_BANKACCOUNT, staff.getBankaccount());
        long result = db.insert(TABLE_STAFF, null, values);
        db.close();
        return result;
    }

    public Staff getStaff(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_STAFF,
                new String[] {KEY_ID, KEY_STAFFFIRSTNAME, KEY_STAFFFLASTNAME, KEY_CONTACTDETAILS, KEY_STAFFEMAIL, KEY_STAFFADDRESS, KEY_BANKACCOUNT}, KEY_ID + "=?",
                new String[] {String.valueOf(id)},null, null, null, null);
        if (cursor != null) {	// the record is available
            cursor.moveToFirst();  // should only get ONE contact
            Staff staff = new Staff((cursor.getString(0)), cursor.getString(1),
                    cursor.getString(2), cursor.getString(3),
                    cursor.getString(4), cursor.getString(5));
            cursor.close();
            db.close();
            return staff;
        }
        else {  // no record for the id provided
            cursor.close();
            db.close();
            return null;
        }
    }

    public int deleteStaff(Staff staff) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsAffected = db.delete(TABLE_STAFF, KEY_ID + "=?",
                new String[]{String.valueOf(staff.getStafffirstname())});
        db.close();
        return rowsAffected;
        }

    public int getStaffCount() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_STAFF, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();
        return count;
    }

    public int updateStaff(Staff staff) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_STAFFFIRSTNAME, staff.getStafffirstname());
        values.put(KEY_STAFFFLASTNAME, staff.getStafflastname());
        values.put(KEY_CONTACTDETAILS, staff.getContactdetails());
        values.put(KEY_STAFFEMAIL, staff.getStaffemail());
        values.put(KEY_STAFFADDRESS, staff.getStaffaddress());
        values.put(KEY_BANKACCOUNT, staff.getBankaccount());
        int rowsAffected = db.update(TABLE_STAFF, values, KEY_ID + "=?",
                new String[]{String.valueOf(staff.getStafffirstname())});
        db.close();
        return rowsAffected;
    }

    public List<Staff> getAllStaff() {
        List<Staff> staffs = new ArrayList<Staff>();
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_STAFF, null);
        if (cursor.moveToFirst()){
            do {
                staffs.add(new Staff((cursor.getString(1)), cursor.getString(2),
                        cursor.getString(3), cursor.getString(4),
                        cursor.getString(5), cursor.getString(6)));
                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
            return staffs;
        }
}
