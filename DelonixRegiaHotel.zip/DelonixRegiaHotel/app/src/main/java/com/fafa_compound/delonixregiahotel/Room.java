package com.fafa_compound.delonixregiahotel;

/**
 * Created by fafa_compound on 9/6/2016.
 */
public class Room {
    private int _id;
    private String _roomid, _firstname, _lastname,  _noofadults, _noofchildren, _checkindate, _checkoutdate, _checkintime, _checkouttime, _contactnumber, _email, _address, _creditcardtype, _cash, _latecheckoutrequest, _roomtype;

    public Room(int id, String roomid, String checkindate, String checkoutdate, String checkintime, String checkouttime, String firstname, String lastname, String noofadults, String noofchildren, String contactnumber, String email, String address, String creditcardtype, String cash, String latecheckoutrequest, String roomtype)
    {
        _id = id;
        _roomid = roomid;
        _checkindate = checkindate;
        _checkoutdate = checkoutdate;
        _checkintime = checkintime;
        _checkouttime = checkouttime;
        _firstname = firstname;
        _lastname = lastname;
        _noofadults = noofadults;
        _noofchildren = noofchildren;
        _contactnumber = contactnumber;
        _email = email;
        _address = address;
        _creditcardtype = creditcardtype;
        _cash = cash;
        _latecheckoutrequest = latecheckoutrequest;
        _roomtype = roomtype;
    }

    public int getId() {return _id;}

    public String getRoomid() {return _roomid;}
    public void setRoomid(String newRoomid) {_roomid = newRoomid;}

    public String getCheckindate() {return _checkindate;}
    public void setCheckindate (String newCheckindate) {_checkindate = newCheckindate;}

    public String getCheckoutdate() {return _checkoutdate;}
    public void setCheckoutdate(String newCheckoutdate) {_checkoutdate = newCheckoutdate;}

    public String getCheckintime() { return _checkintime;}
    public void setCheckintime (String newCheckintime) { _checkintime = newCheckintime; }

    public String getCheckouttime() {return _checkouttime;}
    public void setCheckouttime (String newCheckouttime) { _checkouttime = newCheckouttime;}

    public String getFirstname() {return _firstname;}
    public void setFirstname (String newFirstname) { _firstname = newFirstname;}

    public String getLastname() {return _lastname;}
    public void setLastname (String newLastname) { _lastname = newLastname;}

    public String getNoofadults() {return _noofadults;}
    public void setNoofadults (String newNoofadults) { _noofadults = newNoofadults;}

    public String getNoofchildren() {return _noofchildren;}
    public void setNoofchildren (String newNoofchildren) { _noofchildren = newNoofchildren;}

    public String getContactnumber() {return _contactnumber;}
    public void setContactnumber (String newContactnumber) { _contactnumber = newContactnumber;}

    public String getEmail() {return _email;}
    public void setEmail (String newEmail) { _email = newEmail;}

    public String getAddress() {return _address;}
    public void setAddress (String newAddress) { _address = newAddress;}

    public String getCreditcardtype() {return _creditcardtype;}
    public void setCreditcardtype (String newCreditcardtype) { _creditcardtype = newCreditcardtype;}

    public String getCash() {return _cash;}
    public void setCash (String newCash) { _cash = newCash;}

    public String getLatecheckoutrequest() {return _latecheckoutrequest;}
    public void setLatecheckoutrequest (String newLatecheckoutrequest) { _latecheckoutrequest = newLatecheckoutrequest;}

    public String getRoomtype() {return _roomtype;}
    public void setRoomtype (String newRoomtype) { _roomtype = newRoomtype;}




}
