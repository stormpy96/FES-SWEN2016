package com.example.admin.swen3;

import java.text.NumberFormat;

public class Hotel {
    private long roomID;
    private String NoOfGuest;
    private Double RoomNumber;
    private String RoomStatus;


    public long getId() {
        return roomID;
    }
    public void setId(long id) {
        this.roomID = id;
    }

    public String getNoOfGuest() {
        return NoOfGuest;
    }
    public void setNoOfGuest(String NoOfGuest) {
        this.NoOfGuest = NoOfGuest;
    }

    public double getRoomNumber() {return RoomNumber;}
    public void setRoomNumber(double roomNumber){this.RoomNumber = roomNumber;}

    public String getRoomStatus() {return RoomStatus;}
    public void setRoomStatus(String RoomStatus) {this.RoomStatus = RoomStatus;}




}

