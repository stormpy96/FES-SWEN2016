package com.fafa_compound.delonixregiahotel;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class RoomActivity extends AppCompatActivity {
    TextView mEdit;
    TextView nEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room);

        tabHost2 = (TabHost) findViewById(R.id.tabHost);
        tabHost2.setup();
        TabHost.TabSpec tabSpec = tabHost2.newTabSpec("Add a room"); //First tab
        tabSpec.setContent(R.id.tabCreator);
        tabSpec.setIndicator("Create Booking");
        tabHost2.addTab(tabSpec);

        tabSpec = tabHost2.newTabSpec("RoomList"); //Second tab
        tabSpec.setContent(R.id.tabPlanList);
        tabSpec.setIndicator("View Booking");
        tabHost2.addTab(tabSpec);

        editTextRoomid = (EditText) findViewById(R.id.editTextRoomid);
        textViewCheckindate = (TextView) findViewById(R.id.textViewCheckindate);
        textViewCheckoutdate = (TextView) findViewById(R.id.textViewCheckoutdate);
        editTextCheckintime = (EditText) findViewById(R.id.editTextCheckintime);
        editTextCheckouttime = (EditText) findViewById(R.id.editTextCheckouttime);
        editTextFirstname = (EditText) findViewById(R.id.editTextFirstname);
        editTextLastname = (EditText) findViewById(R.id.editTextLastname);
        editTextNoofadults = (EditText) findViewById(R.id.editTextNoofadults);
        editTextNoofchildren = (EditText) findViewById(R.id.editTextNoofchildren);
        editTextContactnumber = (EditText) findViewById(R.id.editTextContactnumber);
        editTextAddress = (EditText) findViewById(R.id.editTextAddress);
        editTextEmail = (EditText) findViewById(R.id.editTextEmail);
        editTextCreditcardtype = (EditText) findViewById(R.id.editTextCreditcardtype);
        editTextCash = (EditText) findViewById(R.id.editTextCash);
        editTextLatecheckoutrequest = (EditText) findViewById(R.id.editTextLatecheckoutrequest);
        editTextRoomtype = (EditText) findViewById(R.id.editTextRoomtype);

        dbHandler = new DatabaseHandler(getApplicationContext());
        listViewRooms = (ListView) findViewById(R.id.listView);

        btnAdd = (Button) findViewById(R.id.buttonAddPlan);
        btnAdd.setEnabled(false);

        btnAdd.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // create a new contact object, using the values entered
                        Room room = new Room(dbHandler.getRoomCount(),
                                String.valueOf(editTextRoomid.getText()),
                                String.valueOf(textViewCheckindate.getText()),
                                String.valueOf(textViewCheckoutdate.getText()),
                                String.valueOf(editTextCheckintime.getText()),
                                String.valueOf(editTextCheckouttime.getText()),
                                String.valueOf(editTextFirstname.getText()),
                                String.valueOf(editTextLastname.getText()),
                                String.valueOf(editTextNoofadults.getText()),
                                String.valueOf(editTextNoofchildren.getText()),
                                String.valueOf(editTextContactnumber.getText()),
                                String.valueOf(editTextEmail.getText()),
                                String.valueOf(editTextAddress.getText()),
                                String.valueOf(editTextCreditcardtype.getText()),
                                String.valueOf(editTextCash.getText()),
                                String.valueOf(editTextLatecheckoutrequest.getText()),
                                String.valueOf(editTextRoomtype.getText()));

                        if (!RoomExists(room)) { // check if Room exists
                            // use the DB createContact method
                            long result = dbHandler.createRoom(room);
                            if (result == -1) {
                                Toast.makeText(RoomActivity.this, "Room cannot be added!", Toast.LENGTH_SHORT).show();
                            } else {
                                rooms.add(room); // add to ArrayList
                                roomsAdapter.notifyDataSetChanged();
                                Toast.makeText(getApplicationContext(), String.valueOf(editTextRoomid.getText()) + " has been added!", Toast.LENGTH_SHORT).show();
                            }
                        } else
                            Toast.makeText(getApplicationContext(), String.valueOf(editTextRoomid.getText()) + " already exists!", Toast.LENGTH_SHORT).show();
                    }



                }

        );

        editTextRoomid.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if ((String.valueOf(editTextRoomid.getText()).trim().isEmpty()))
                            btnAdd.setEnabled(false); //Required field
                        else
                            btnAdd.setEnabled(true); //Required field
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                    }
                }
        );

        populateList();
        if (dbHandler.getRoomCount() != 0 && rooms.size() == 0)
            rooms.addAll(dbHandler.getAllRoom());

        registerForContextMenu(listViewRooms);
        listViewRooms.setOnItemLongClickListener(
                new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                        longClickedItemIndex = position;
                        return false;
                    }
                }
        );

    }

    private static final int _EDIT = 0, _DELETE = 1; // constants to be used later
    static int longClickedItemIndex;

    EditText editTextRoomid, editTextCheckintime, editTextCheckouttime, editTextFirstname, editTextLastname, editTextNoofadults, editTextNoofchildren, editTextContactnumber, editTextEmail, editTextAddress, editTextCreditcardtype, editTextCash, editTextLatecheckoutrequest, editTextRoomtype;
    TextView textViewCheckindate, textViewCheckoutdate;
    Button btnAdd;
    TabHost tabHost2;

    static List<Room> rooms = new ArrayList<Room>();
    ArrayAdapter<Room> roomsAdapter;
    ListView listViewRooms;

    static DatabaseHandler dbHandler;

    private boolean RoomExists(Room room) {
        String name = room.getRoomid();
        int roomCount = rooms.size();
        for (int i = 0; i < roomCount; i++) {
            // compare the name with all the names in the ArrayList
            if (name.compareToIgnoreCase(rooms.get(i).getRoomid()) == 0)
                return true;
        }
        return false;
    }

    public void onActivityResult(int reqCode, int resCode, Intent data) {
        roomsAdapter.notifyDataSetChanged();
    }


    public class roomListAdapter extends ArrayAdapter<Room> {
        public roomListAdapter() {
            super(RoomActivity.this, R.layout.listviewroom, rooms);
        }

        @Override
        public View getView(int position, View view, ViewGroup parent) {
            Room currentRoom = rooms.get(position);
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.listviewroom, parent, false);
            }

            TextView roomid = (TextView) view.findViewById(R.id.textViewRoomid);
            roomid.setText(currentRoom.getRoomid());
            TextView checkindate = (TextView) view.findViewById(R.id.textViewCheckindate);
            checkindate.setText(currentRoom.getCheckindate());
            TextView checkoutdate = (TextView) view.findViewById(R.id.textViewCheckoutdate);
            checkoutdate.setText(currentRoom.getCheckoutdate());
            TextView checkintime = (TextView) view.findViewById(R.id.textViewCheckintime);
            checkintime.setText(currentRoom.getCheckintime());
            TextView checkouttime = (TextView) view.findViewById(R.id.textViewCheckouttime);
            checkouttime.setText(currentRoom.getCheckouttime());
            TextView firstname = (TextView) view.findViewById(R.id.textViewFirstname);
            firstname.setText(currentRoom.getFirstname());
            TextView lastname = (TextView) view.findViewById(R.id.textViewLastname);
            lastname.setText(currentRoom.getLastname());
            TextView noofadults = (TextView) view.findViewById(R.id.textViewNoofadults);
            noofadults.setText(currentRoom.getNoofadults());
            TextView noofchildren = (TextView) view.findViewById(R.id.textViewNoofchildren);
            noofchildren.setText(currentRoom.getNoofchildren());
            TextView contactnumber = (TextView) view.findViewById(R.id.textViewContactnumber);
            contactnumber.setText(currentRoom.getContactnumber());
            TextView email = (TextView) view.findViewById(R.id.textViewEmail);
            email.setText(currentRoom.getEmail());
            TextView address = (TextView) view.findViewById(R.id.textViewAddress);
            address.setText(currentRoom.getAddress());
            TextView creditcardtype = (TextView) view.findViewById(R.id.textViewCreditcardtype);
            creditcardtype.setText(currentRoom.getCreditcardtype());
            TextView cash = (TextView) view.findViewById(R.id.textViewCash);
            cash.setText(currentRoom.getCash());
            TextView latecheckoutrequest = (TextView) view.findViewById(R.id.textViewLatecheckoutrequest);
            latecheckoutrequest.setText(currentRoom.getLatecheckoutrequest());
            TextView roomtype = (TextView) view.findViewById(R.id.textViewRoomtype);
            roomtype.setText(currentRoom.getRoomtype());

            return view;
        }
    }

    private void populateList() {
        roomsAdapter = new roomListAdapter();
        listViewRooms.setAdapter(roomsAdapter);
    }

    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, view, menuInfo);
        menu.setHeaderTitle("Booking Options:");
        menu.add(Menu.NONE, _EDIT, Menu.NONE, "Edit Booking");
        menu.add(Menu.NONE, _DELETE, Menu.NONE, "Delete Booking");
    }

    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case _EDIT:
                // editing a contact
                Intent editRoomIntent = new Intent(getApplicationContext(), EditRoom.class);
                startActivityForResult(editRoomIntent, 2); // reqcode=2
                break;
            case _DELETE:
                AlertDialog.Builder a_builder = new AlertDialog.Builder(RoomActivity.this);
                a_builder.setMessage("Are you sure you want to delete?")
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        })
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dbHandler.deleteRoom(rooms.get(longClickedItemIndex));
                                rooms.remove(longClickedItemIndex);
                                roomsAdapter.notifyDataSetChanged();
                            }
                        })
                        .setCancelable(false);
                AlertDialog alert = a_builder.create();
                alert.setTitle("Confirmation ! ");
                alert.show();
                break;
        }
        return super.onContextItemSelected(item);
    }

    public void selectDate(View view) {
        DialogFragment newFragment = new SelectDateFragment();
        newFragment.show(getSupportFragmentManager(), "DatePicker");
    }

    public void populateSetDate(int year, int month, int day) {
        mEdit = (TextView) findViewById(R.id.textViewCheckindate);
        mEdit.setText(month + "/" + day + "/" + year);
    }

    public class SelectDateFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar calendar = Calendar.getInstance();
            int yy = calendar.get(Calendar.YEAR);
            int mm = calendar.get(Calendar.MONTH);
            int dd = calendar.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, yy, mm, dd);
        }

        public void onDateSet(DatePicker view, int yy, int mm, int dd) {
            Calendar cl1 = Calendar.getInstance();
            cl1.set(yy, mm, dd);
            if (cl1.after(Calendar.getInstance())) {
                populateSetDate(yy, mm + 1, dd);
            } else {
                Toast.makeText(getApplicationContext(), "Please enter a date after today's date", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void selectDate2(View view) {
        DialogFragment newFragment = new SelectDateFragment2();
        newFragment.show(getSupportFragmentManager(), "DatePicker");
    }

    public void populateSetDate2(int year, int month, int day) {
        nEdit = (TextView) findViewById(R.id.textViewCheckoutdate);
        nEdit.setText(month + "/" + day + "/" + year);
    }

    public class SelectDateFragment2 extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar calendar = Calendar.getInstance();
            int yy = calendar.get(Calendar.YEAR);
            int mm = calendar.get(Calendar.MONTH);
            int dd = calendar.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, yy, mm, dd);
        }

        public void onDateSet(DatePicker view, int yy, int mm, int dd) {

            Calendar cl = Calendar.getInstance();
            cl.set(yy, mm, dd);
            if (cl.after(Calendar.getInstance())) {
                populateSetDate2(yy, mm + 1, dd);
            } else {

                Toast.makeText(getApplicationContext(), "Please enter a date after today's date", Toast.LENGTH_SHORT).show();
            }
        }
    }
}








