package com.fafa_compound.delonixregiahotel;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


/**
 * Created by fafa_compound on 8/6/2016.
 */
public class EditStaff extends FragmentActivity {
    TextView mEdit;
    TextView nEdit;
    DatabaseHandler dbHandler = StaffActivity.dbHandler;
    TextView firstname, lastname, contactnumber, email, address, bankaccount;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_staff);

        // Get the plan to be updated
        final Staff tempStaff = StaffActivity.staffs.get(StaffActivity.longClickedItemIndex);

        firstname = (TextView) findViewById(R.id.txtEditStaffFirstname);
        firstname.setText(tempStaff.getStafffirstname());
        lastname = (TextView) findViewById(R.id.txtEditStaffLastname);
        lastname.setText(tempStaff.getStafflastname());
        contactnumber = (TextView) findViewById(R.id.txtEditContactnumber);
        contactnumber.setText(tempStaff.getContactdetails());
        email = (TextView) findViewById(R.id.txtEditEmail);
        email.setText(tempStaff.getStaffemail());
        address = (TextView) findViewById(R.id.txtEditAddress);
        address.setText(tempStaff.getStaffaddress());
        bankaccount = (TextView) findViewById(R.id.txtEditBankaccount);
        bankaccount.setText(tempStaff.getBankaccount());

        Button btnDone = (Button) findViewById(R.id.btnEditUpdate);
        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tempStaff.setStafffirstname(String.valueOf(firstname.getText()));
                tempStaff.setStafflastname(String.valueOf(lastname.getText()));
                tempStaff.setContactdetails(String.valueOf(contactnumber.getText()));
                tempStaff.set_Staffemail(String.valueOf(email.getText()));
                tempStaff.set_Staffaddress(String.valueOf(address.getText()));
                tempStaff.setBankaccount(String.valueOf(bankaccount.getText()));

                dbHandler.updateStaff(tempStaff);

                Intent returnIntent = new Intent();
                setResult(RESULT_OK, returnIntent);
                finish();
            }
        });

    }
}



