package com.fafa_compound.delonixregiahotel;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private static Button button_staff;
    private static Button button_room;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        OnClickButtonListener();
    }

    public void OnClickButtonListener() {
        button_staff = (Button) findViewById(R.id.buttonStaff);
        button_staff.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent2 = new
                                Intent(MainActivity.this, StaffActivity.class);
                        startActivity(intent2);
                    }
                }
        );
        button_room = (Button) findViewById(R.id.buttonRoom);
        button_room.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent2 = new
                                Intent(MainActivity.this, RoomActivity.class);
                        startActivity(intent2);
                    }
                }
        );
    }
}
