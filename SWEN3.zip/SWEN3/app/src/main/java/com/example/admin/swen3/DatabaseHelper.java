package com.example.admin.swen3;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME="hotel.db";
    public static final String TABLE_NAME="room_table";
    public static final String ROOM_ID="Room ID";
    public static final String NO_OF_GUEST="No of Guest";
    public static final String ROOM_NUMBER="Room Number";
    public static final String ROOM_STATUS="Room STatus";

    public static final String STAFF_ID="StaffID";
    public static final String STAFF_NAME="Staff Name";
    public static final String DUTY_TYPE="Duty Type";
    public static final String DUTY_DATE="Duty Date";
    public static final String DUTY_START_TIME="Duty Start Time";
    public static final String DUTY_END_TIME="Duty End Time";

    public static final String NO_OF_ADULT="Number of Adult";
    public static final String NO_OF_CHILDREN="Number of Children";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + "("
                + ROOM_ID +" INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NO_OF_GUEST +" INTEGER, "
                + ROOM_NUMBER +" INTEGER, "
                + ROOM_STATUS +" TEXT, "

                + STAFF_ID +" INTEGER PRIMARY KEY AUTOINCREMENT, "
                + STAFF_NAME +" TEXT, "
                + DUTY_TYPE +" TEXT, "
                + DUTY_DATE +" INTEGER, "
                + DUTY_START_TIME +" INTEGER, "
                + DUTY_END_TIME +" INTEGER, "

                + NO_OF_ADULT +"INTEGER, "
                + NO_OF_CHILDREN + "INTEGER)"
        );

    }

    public boolean insertData(String NumberofGuest , Double RoomNumber, String RoomStatus)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NO_OF_GUEST, NumberofGuest );
        contentValues.put(ROOM_NUMBER, RoomNumber);
        contentValues.put(ROOM_STATUS, RoomStatus );
        long result = db.insert(TABLE_NAME, null, contentValues);
        if (result == -1)
            return false;
        else
            return true;
    }


    public Cursor getAllData()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor results = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        return results;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
        onCreate(db);

    }

    public static void open() {
    }

    public static void findAll() {
    }
}
