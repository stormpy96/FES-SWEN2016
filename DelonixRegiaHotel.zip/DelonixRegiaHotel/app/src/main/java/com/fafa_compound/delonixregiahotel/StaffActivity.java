package com.fafa_compound.delonixregiahotel;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fafa_compound on 8/6/2016.
 */
public class StaffActivity extends AppCompatActivity {
    TextView mEdit;
    TextView nEdit;
    private static final int _EDIT = 0, _DELETE = 1; // constants to be used later
    static int longClickedItemIndex;

    EditText editTextStaffFirstname, editTextStaffLastname, editTextContactnumber, editTextEmail, editTextAddress, editTextBankaccount;

    Button buttonAddstaff;
    TabHost tabHost2;

    static List<Staff> staffs = new ArrayList<Staff>();
    ArrayAdapter<Staff> staffsAdapter;
    ListView listViewStaffs;

    static DatabaseHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff);

        tabHost2 = (TabHost) findViewById(R.id.tabHost);
        tabHost2.setup();
        TabHost.TabSpec tabSpec = tabHost2.newTabSpec("Add Staff"); //First tab
        tabSpec.setContent(R.id.tabCreator);
        tabSpec.setIndicator("Add Staff");
        tabHost2.addTab(tabSpec);

        tabSpec = tabHost2.newTabSpec("Staff List"); //Second tab
        tabSpec.setContent(R.id.tabStaffList);
        tabSpec.setIndicator("View Staff Details");
        tabHost2.addTab(tabSpec);

        editTextStaffFirstname = (EditText) findViewById(R.id.editTextStaffFirstname);
        editTextStaffLastname = (EditText) findViewById(R.id.editTextStaffLastname);
        editTextContactnumber = (EditText) findViewById(R.id.editTextContactnumber);
        editTextAddress = (EditText) findViewById(R.id.editTextAddress);
        editTextEmail = (EditText) findViewById(R.id.editTextEmail);
        editTextBankaccount = (EditText) findViewById(R.id.editTextBankaccount);

        dbHandler = new DatabaseHandler(getApplicationContext());
        listViewStaffs = (ListView) findViewById(R.id.listView);

        buttonAddstaff = (Button) findViewById(R.id.buttonAddStaff);
        buttonAddstaff.setEnabled(false);

        buttonAddstaff.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // create a new contact object, using the values entered
                        Staff staff = new Staff(String.valueOf(editTextStaffFirstname.getText()),
                                String.valueOf(editTextStaffLastname.getText()),
                                String.valueOf(editTextContactnumber.getText()),
                                String.valueOf(editTextEmail.getText()),
                                String.valueOf(editTextAddress.getText()),
                                String.valueOf(editTextBankaccount.getText()));
                        if (!StaffExists(staff)) { // check if contact name exists
                            // use the DB createContact method
                            long result = dbHandler.createStaff(staff);
                            if (result == -1) {
                                Toast.makeText(StaffActivity.this, "Staff details cannot be added!", Toast.LENGTH_SHORT).show();
                            } else {
                                staffs.add(staff); // add to ArrayList
                                staffsAdapter.notifyDataSetChanged();
                                Toast.makeText(getApplicationContext(), String.valueOf(editTextStaffFirstname.getText()) + " has been added!", Toast.LENGTH_SHORT).show();
                            }
                        } else
                            Toast.makeText(getApplicationContext(), String.valueOf(editTextStaffFirstname.getText()) + " already exists!", Toast.LENGTH_SHORT).show();
                    }


                }

        );

        editTextStaffFirstname.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if ((String.valueOf(editTextStaffFirstname.getText()).trim().isEmpty()))
                            buttonAddstaff.setEnabled(false); //Required field
                        else
                            buttonAddstaff.setEnabled(true); //Required field
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                    }
                }
        );
        if (dbHandler.getStaffCount() != 0 && staffs.size() == 0) {
            staffs.addAll(dbHandler.getAllStaff());
        }
        registerForContextMenu(listViewStaffs);
        listViewStaffs.setOnItemLongClickListener(
                new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                        longClickedItemIndex = position;
                        return false;
                    }
                }
        );
        populateList();
    }

    private boolean StaffExists(Staff staff) {
        String name = staff.getStafffirstname();
        int staffCount = staffs.size();
        for (int i = 0; i < staffCount; i++) {
            // compare the name with all the names in the ArrayList
            if (name.compareToIgnoreCase(staffs.get(i).getStafffirstname()) == 0)
                return true;
        }
        return false;
    }

    public void onActivityResult(int reqCode, int resCode, Intent data) {
        staffsAdapter.notifyDataSetChanged();
    }

    public class staffListAdapter extends ArrayAdapter<Staff> {
        public staffListAdapter() {
            super(StaffActivity.this, R.layout.listviewstaff, staffs);
        }

        @Override
        public View getView(int position, View view, ViewGroup parent) {
            Staff currentStaff = staffs.get(position);
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.listviewstaff, parent, false);
            }

            TextView firstname = (TextView) view.findViewById(R.id.textViewFirst);
            firstname.setText(currentStaff.getStafffirstname());
            TextView lastname = (TextView) view.findViewById(R.id.textViewLast);
            lastname.setText(currentStaff.getStafflastname());
            TextView contactdetails = (TextView) view.findViewById(R.id.textViewContact);
            contactdetails.setText(currentStaff.getContactdetails());
            TextView email = (TextView) view.findViewById(R.id.textViewEmail);
            email.setText(currentStaff.getStaffemail());
            TextView address = (TextView) view.findViewById(R.id.textViewAddress);
            address.setText(currentStaff.getStaffaddress());
            TextView bankaccount = (TextView) view.findViewById(R.id.textViewBank);
            bankaccount.setText(currentStaff.getBankaccount());

            return view;
        }
    }

    private void populateList() {
        staffsAdapter = new staffListAdapter();
        listViewStaffs.setAdapter(staffsAdapter);
    }

    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, view, menuInfo);

        menu.setHeaderTitle("Staff Details Options:");
        menu.add(Menu.NONE, _EDIT, Menu.NONE, "Edit Staff Details");
        menu.add(Menu.NONE, _DELETE, Menu.NONE, "Delete Staff Details");
    }

    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case _EDIT:
                Intent editStaffIntent = new Intent(getApplicationContext(), EditStaff.class);
                startActivityForResult(editStaffIntent, 2);
                break;
            case _DELETE:
                AlertDialog.Builder a_builder = new AlertDialog.Builder(StaffActivity.this);
                a_builder.setMessage("Are you sure you want to delete?")
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        })
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dbHandler.deleteStaff(staffs.get(longClickedItemIndex));
                                staffs.remove(longClickedItemIndex);
                                staffsAdapter.notifyDataSetChanged();
                            }
                        })
                        .setCancelable(false);
                AlertDialog alert = a_builder.create();
                alert.setTitle("Confirm?");
                alert.show();
                break;
        }
        return super.onContextItemSelected(item);
    }
}



