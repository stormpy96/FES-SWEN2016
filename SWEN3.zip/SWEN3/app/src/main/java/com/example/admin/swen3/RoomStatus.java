package com.example.admin.swen3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class RoomStatus extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_status);
    }

    //Referencing the Database
    db1 = new DatabaseHelper(this);
    DatabaseHelper.open();

    //Check to see if there are records, if not call the createData to add some records
    Hotel= DatabaseHelper.findAll();
    if (Hotel.size() == 0) {
        createData();
        Hotel = DatabaseHelper.findAll();
    }
}
    //opening the DB when app returns from standby
    @Override
    protected void onResume() {
        super.onResume();
        DatabaseHelper.open();
    }
    //pausing the DB when app is paused
    @Override
    protected void onPause() {
        super.onPause();
        DatabaseHelper.close();
    }

    private void createData() {
        Hotel hotel = new Hotel();
        hotel.setRoomNumber(111);
        hotel.setNoOfGuest("3");
        hotel.setRoomStatus("Occupied");

        Log.i(LOGTAG, "Tour created with id " + tour.getId());



    }


}
