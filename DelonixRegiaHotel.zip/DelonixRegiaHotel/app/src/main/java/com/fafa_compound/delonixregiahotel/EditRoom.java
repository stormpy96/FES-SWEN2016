package com.fafa_compound.delonixregiahotel;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

/**
 * Created by syamir96 on 14/2/2016.
 */
public class EditRoom extends FragmentActivity {
    TextView mEdit;
    TextView nEdit;
    DatabaseHandler dbHandler = RoomActivity.dbHandler;
    TextView roomid, checkindate, checkoutdate, checkintime, checkouttime, firstname, lastname, noofadults, noofchildren, contactnumber, email, address, creditcardtype, cash, latecheckoutrequest, roomtype;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_room);

        // Get the plan to be updated
        final Room tempRoom = RoomActivity.rooms.get(RoomActivity.longClickedItemIndex);

        roomid = (TextView) findViewById(R.id.txtEditRoomid);
        roomid.setText(tempRoom.getRoomid());

        checkindate = (TextView) findViewById(R.id.txtEditCheckinDate);
        checkindate.setText(tempRoom.getCheckindate());

        checkoutdate = (TextView) findViewById(R.id.txtEditCheckoutDate);
        checkoutdate.setText(tempRoom.getCheckoutdate());

        checkintime = (TextView) findViewById(R.id.txtEditCheckinTime);
        checkintime.setText(tempRoom.getCheckintime());

        checkouttime = (TextView) findViewById(R.id.txtEditCheckoutTime);
        checkouttime.setText(tempRoom.getCheckouttime());

        firstname = (TextView) findViewById(R.id.txtEditFirstname);
        firstname.setText(tempRoom.getFirstname());

        lastname = (TextView) findViewById(R.id.txtEditLastname);
        lastname.setText(tempRoom.getLastname());

        noofadults = (TextView) findViewById(R.id.txtEditNoofadults);
        noofadults.setText(tempRoom.getNoofadults());

        noofchildren = (TextView) findViewById(R.id.txtEditNoofchildren);
        noofchildren.setText(tempRoom.getNoofchildren());

        contactnumber = (TextView) findViewById(R.id.txtEditContactnumber);
        contactnumber.setText(tempRoom.getContactnumber());

        email = (TextView) findViewById(R.id.txtEditEmail);
        email.setText(tempRoom.getEmail());

        address = (TextView) findViewById(R.id.txtEditAddress);
        address.setText(tempRoom.getAddress());

        creditcardtype = (TextView) findViewById(R.id.txtEditCreditcardtype);
        creditcardtype.setText(tempRoom.getCreditcardtype());

        cash = (TextView) findViewById(R.id.txtEditCash);
        cash.setText(tempRoom.getCash());

        latecheckoutrequest = (TextView) findViewById(R.id.txtEditLatecheckoutrequest);
        latecheckoutrequest.setText(tempRoom.getLatecheckoutrequest());

        roomtype = (TextView) findViewById(R.id.txtEditRoomtype);
        roomtype.setText(tempRoom.getRoomtype());

        Button btnDone = (Button) findViewById(R.id.btnEditDone);
        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tempRoom.setRoomid(String.valueOf(roomid.getText()));
                tempRoom.setCheckindate(String.valueOf(checkindate.getText()));
                tempRoom.setCheckoutdate(String.valueOf(checkoutdate.getText()));
                tempRoom.setCheckintime(String.valueOf(checkintime.getText()));
                tempRoom.setCheckouttime(String.valueOf(checkouttime.getText()));
                tempRoom.setFirstname(String.valueOf(firstname.getText()));
                tempRoom.setLastname(String.valueOf(lastname.getText()));
                tempRoom.setNoofadults(String.valueOf(noofadults.getText()));
                tempRoom.setNoofchildren(String.valueOf(noofchildren.getText()));
                tempRoom.setContactnumber(String.valueOf(contactnumber.getText()));
                tempRoom.setEmail(String.valueOf(email.getText()));
                tempRoom.setAddress(String.valueOf(address.getText()));
                tempRoom.setCreditcardtype(String.valueOf(creditcardtype.getText()));
                tempRoom.setCash(String.valueOf(cash.getText()));
                tempRoom.setLatecheckoutrequest(String.valueOf(latecheckoutrequest.getText()));
                tempRoom.setRoomtype(String.valueOf(roomtype.getText()));

                dbHandler.updateRoom(tempRoom);

                Intent returnIntent = new Intent();
                setResult(RESULT_OK, returnIntent);
                finish();
            }
        });

    }

    // Function to capture our start activity for result (dont need override)

    public void selectDate(View view) {
        DialogFragment newFragment = new SelectDateFragment();
        newFragment.show(getSupportFragmentManager(), "DatePicker");
    }
    public void populateSetDate(int year, int month, int day) {
        mEdit = (TextView)findViewById(R.id.txtEditCheckinDate);
        mEdit.setText(month+"/"+day+"/"+year);
    }

    public class SelectDateFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar calendar = Calendar.getInstance();
            int yy = calendar.get(Calendar.YEAR);
            int mm = calendar.get(Calendar.MONTH);
            int dd = calendar.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, yy, mm, dd);
        }

        public void onDateSet(DatePicker view, int yy, int mm, int dd) {
            Calendar cl = Calendar.getInstance();
            cl.set(yy, mm, dd);
            if (cl.after(Calendar.getInstance())) {
                populateSetDate(yy, mm + 1, dd);
            }else{
                Toast.makeText(getApplicationContext(), "Please enter a date after today's date", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void selectDate2(View view) {
        DialogFragment newFragment = new SelectDateFragment2();
        newFragment.show(getSupportFragmentManager(), "DatePicker");
    }
    public void populateSetDate2(int year, int month, int day) {
        nEdit = (TextView)findViewById(R.id.txtEditCheckoutDate);
        nEdit.setText(month+"/"+day+"/"+year);
    }
    public class SelectDateFragment2 extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar calendar = Calendar.getInstance();
            int yy = calendar.get(Calendar.YEAR);
            int mm = calendar.get(Calendar.MONTH);
            int dd = calendar.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, yy, mm, dd);
        }

        public void onDateSet(DatePicker view, int yy, int mm, int dd) {
            populateSetDate2(yy, mm+1, dd);
        }
    }

}