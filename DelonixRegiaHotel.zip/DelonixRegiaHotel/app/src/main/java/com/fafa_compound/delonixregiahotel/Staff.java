package com.fafa_compound.delonixregiahotel;

/**
 * Created by fafa_compound on 8/6/2016.
 */
public class Staff {
    private String _stafffirstname, _stafflastname, _contactdetails, _staffemail, _staffaddress, _bankaccount;

    public Staff (String stafffirstname, String stafflastname, String contactdetails, String staffemail, String staffaddress, String bankaccount)
    {
        _stafffirstname = stafffirstname;
        _stafflastname = stafflastname;
        _contactdetails = contactdetails;
        _staffemail = staffemail;
        _staffaddress = staffaddress;
        _bankaccount = bankaccount;
    }

    public String getStafffirstname() {return _stafffirstname;}
    public void setStafffirstname(String newstafffirstname) {_stafffirstname = newstafffirstname;}

    public String getStafflastname() {return _stafflastname;}
    public void setStafflastname(String newstafflastname) {_stafflastname = newstafflastname;}

    public String getContactdetails() {return _contactdetails;}
    public void setContactdetails(String newcontactdetails) {_contactdetails = newcontactdetails;}

    public String getStaffemail() {return _staffemail;}
    public void set_Staffemail(String newstaffemail) {_staffemail = newstaffemail;}

    public  String getStaffaddress() {return _staffaddress;}
    public void set_Staffaddress(String newstaffaddress) {_staffaddress = newstaffaddress;}

    public String getBankaccount() {return _bankaccount;}
    public void setBankaccount(String newbankaccount) {_bankaccount = newbankaccount;}

}
